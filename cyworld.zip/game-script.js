const startWord = () => {
  let myword = document.querySelector("#myword").value;
  let word = document.querySelector("#word").innerHTML;

  let lastword = word[word.length -1];
  let firstword = myword[0];

  if(lastword === firstword) {
    document.querySelector("#result").innerHTML = "정답입니다."
    document.querySelector("#word").innerHTML = myword;
    document.querySelector("#myword").value = "";
  } else {
    document.querySelector("#result").innerHTML = "틀렸습니다."
  }
}

let lottoBtn = document.querySelector(".wrpaer-lotto-btn");
let lottoNumber = document.querySelectorAll(".game-lotto-number > span");

lottoBtn.addEventListener("click", function() {
  let lottoRandom = [];
  for(let i = 0; i < 6; i++) {
    let num
    while(true) {
      num = Math.floor(Math.random()*45) + 1;
      if(lottoRandom.indexOf(num) === -1) {
        lottoRandom.push(num)
        break;
      }
    }
    lottoNumber[i].innerHTML = lottoRandom[i];
  }
})