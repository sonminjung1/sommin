const startWord = () => {
  let myword = document.querySelector("#myword").value;
  let word = document.querySelector("#word").innerHTML;

  let lastword = word[word.length -1];
  let firstword = myword[0];

  if(lastword === firstword) {
    document.querySelector("#result").innerHTML = "정답입니다."
    document.querySelector("#word").innerHTML = myword;
    document.querySelector("#myword").value = "";
  } else {
    document.querySelector("#result").innerHTML = "틀렸습니다."
  }
}