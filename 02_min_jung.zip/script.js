// 로컬 스토리지에 데이터 저장하기

const section = document.querySelector('.localStorage');
const btnRead = document.querySelector('.btnRead');
const btnSave = document.querySelector('.btnSave');
const input = document.querySelector('input');

btnSave.addEventListener('click', () => {
  const data = input.value;
  
  localStorage.setItem('key', data);
});

btnRead.addEventListener('click', () => {
  const data = localStorage.getItem('key');
  
  // input.value = data;
});