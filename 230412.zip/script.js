// * 자바스크립트 소스를 작성하는 3가지 방법!!!

// 1. 인라인 스크립트 : html 안에 자바스크립트 소스 넣기
// 2. 내부 스크립트 
// 3. 외부 스크립트


//실수 : ex) 0.9 / 0.5 와 같은 소수점을 가지고있는 숫자
//난수 : 실수와 같은 숫자가 무작위로 선택되어서 나오는 숫자

// 배경 색상 랜덤으로 변경하는 방법
{/* <script>
function random(number) {
  return Math.floor(Math.random() * number);
}

function bgChange() {
  const rndColor = 'rgb(' + random(255) + ',' + random(255) + ',' + random(255) + ')';
  document.body.style.backgroundColor = rndColor;
}

bgChange();
</script> */}


// ● 자바스크립트에서 자주 사용하는 내장 함수 BEST 3
// alert();
// > 알림창을 표시할 때 사용하는 함수
// confirm();
// > 확인/취소 버튼을 활용해서 사용자로부터 어떠한 동작을 유도할 때 사용하는 함수
// prompt();
// > 사용자가 간단한 값을 입력할 수 있는 함수

// 변수는 바구니라고 생각하세요 ^_^
// ● 변수 = variable = 변할 수 있는 값 > let / var
// > 자바스크립트 : 프로그램에서 사용하기위해 값을 담아 놓는 바구니!

// > 계란 (*함수), 우유(*객체)

// ● 상수 = 고정되어 있는 값 > const

// 1. 변수이름은 숫자로 시작할 수 없음
// ex) 90current

// 2. 변수 이름 안에는 공백이 들어올 수 없음
// ex) now current

// 3. 변수 이름은 영문자 및 특수문자(*_$)
// let current
// let $current

// 4. 기존 자바스크립트 안에 미리 정해놓은 예약어는 사용 불가!!
// - console / document

// 5. 무의미한 변수명은 사용하지 않는다!

// 변수선언 = 변수생성

// let 변수명
// const 변수명
// * 변수값 할당
// 변수 = 값


// ● 나이 계산 공식
// = 현재년도 = 내가 태어난 년도 + 1

// > 현재년도는 const
// > 내가 태어난년도는 let

// const currentYear = 2023;
// let birthYear = prompt("태어난 년도를 입력하세요", "ex) 1995")

// let age = currentYear - birthYear + 1;

// document.write(age);

// ● 호이스팅 : 사전적 의미 = 끌어올리다 !

// var 키워드 : 호이스팅 됩니다!
// let / const 키워드 : 호이스팅 안됩니다!


// ● 자바스크립트 자료형!!
// 숫자형 / 문자열 / 논리형

// > 논리형 = 불리언(Boolean)

// [확인하는 방법!]
// let data = 5;
// undefined
// typeof(data);
// 'number'
// let data1 = "50"
// undefined
// typeof(data1)
// 'string'



// [한줄 건너뛰기]
// console.log('안녕\n하세요!')
// 안녕
// 하세요!

// [tap]
// console.log('안녕\t하세요!')
// 1 안녕	하세요!

// [영문 줄임]
// console.log('i\'m studying now')
// i'm studying now

// let name = prompt("당신의 이름은?");
// let classRoom = prompt("입장하고싶은 강의실은?");
// // document.write(name + "님 " + classRoom + "호 강의실로 입장하세요!");
// document.write(`${name}님, ${classRoom}호로 입장해주시기 바랍니다.`);
// >> ``을 이용하여 사용하긔!!!!!!!!!! ★★ 잊어버리지 말자

// > 템플릿 리터럴 : 문자열과 변수와 함수 등의 식을 하나의 문자열로 만드는 표현 방법 및 형식

// let userNname = prompt("당신의 이름은?");
// document.write(`${userNname}님, 반갑습니다. 🐸`)
// console.log(`${userNname}님, 반갑습니다. 🐸`)


// ● 객체란?
// > 여러개의 자료유형을 하나로 묶어놓은 형태!!!!!!

// [객체형태]
// 객체명 = {
//   key : value,
//   key : value,
//   key : value,
//   key : value

//   key : value => 한쌍 property (*프로퍼티)
// }

// let bookInfo = 100; > 단순 변수
// let bookInfo = {
//   title : "원데이 발란스",
//   page : 278,
//   pubDate : "2023.04.11"
// }

// 접근연산자 "."
// [] 대괄호 사용해서 호출할 수 있습니다.

// let goods = {
//   name : "미르 사이렌 민트 텀블러",
//   height : 591,
//   delivery : "CJ대한통운",
//   deliveryFee : 2500,
//   price : 35000
// }

// goods[price]

// ● 객체 유형 중 하나 = > 배열 객체 ★ => 인덱스 값을 가짐
// 인데스란 ? 아이템 개수를 셀 때 사용하는 속성 기능 => 객체명.length

// let color = ["red", "blue", "pink"]

// Symbol() : 객체의 자료 중 유일한 혹은 유니크한 키 값을 부여하고 싶을 때 사용하는 함수 > 한번 정의하면 변경 혹은 삭제가 절대 안됌!

// 콘솔창에 쓴 것 !
// let id = Symbol();
// undefined
// const member = {
//     name : "kim",
//     [id] : 2580
// }
// undefined
// member;
// {name: 'kim', Symbol(): 2580}
// member.id = 1004;
// 1004
// member;
// {name: 'kim', id: 1004, Symbol(): 2580}
// let grade = Symbol("grade");
// undefined
// member[grade] = "vip"
// 'vip'
// member
// {name: 'kim', id: 1004, Symbol(): 2580, Symbol(grade): 'vip'}
// id
// : 
// 1004
// name
// : 
// "kim"
// Symbol()
// : 
// 2580
// Symbol(grade)
// : 
// "vip"

// ● 숫자로 바꿔주기 (콘솔창)

// let user_Input = prompt("숫자를 입력해 주세요!");
// undefined
// typeof(user_Input)
// 'string'
// user_Input
// '100'
// parseInt(user_Input)
// 100

// > parseInt(변수명) = 문자를 숫자로 바꿔주는 함수
// > parseFloat(변수명) = 문자를 숫자로 바꿔주는 함수 (소수점)

// 숫자인지 문자인지 확인하는 방법 = typeof(변수명)


// ● 다른 타입의 자료형을 문자열로 변환할 때,
// 사용하는 함수는 String() 입니다.

// 간단하게 숫자나 문자열로 변환하는 방법

// Number() / parseInt() / parseFloat() / String()
// 변수명 = +변수명 => 숫자형으로 변경된다

// 변수명 = 변수명+ ""; => 문자열로 변경된다

// 다른 유형의 데이터를 논리형 데이터로 변환하고싶다면,
// Boolean()

// ● 화씨 섭씨 변환하는 방법!!
// let fahrenheit = parseInt(prompt("화씨온도는 몇도인가요?"));
// let celsius = ((fahrenheit-32) / 1.8).toFixed(1);

// alert(`화씨 ${fahrenheit}는 섭씨${celsius}도입니다.`)

// ● 연산자 !!!

// 1. 산술연산자 (+ / - / * / / / %)
// > 증감 연산자!! (증가 연산자 i++ /  ++i 그리고 감소 연산자 i-- / --i)

// 2. 할당 연산자 = 대입 연산자
// ex) y = y + x;
// y += x;

// 3. 비교연산자 > < / >= <=
// > 피연산자가 값이 같다 ==
// > === 이건 엄격하게 비교한다 > 문자인지 숫자인지 매우 중요!

// 4. 논리연산자 (Boolean)
// true / false 

// A && B : 양쪽의 피연산자 값이 모두 true인 경우에만 true
// A || B : 양쪽의 피연산자 값중 어느 하나만이라도 true이면, 결과값은 true

// ● 제어문 종류 !!!

// if문  / else문 / if else문 / continue문 / break문 / for문 / for of문 / for in문 / switch문 / while문 / do while문

// if문
// ============================================
// if(조건) {
//   참일때 실행 할 명령값
// } else {
//   거짓일 때 명령값
// }

// 조건문에서 중괄호 {} 생략 언제 가능 ? 
// 1. flase 값을 설정하지 않은 경우
// 2. 줄코딩을 할 수 있을 만큼 간단한 조건식인 경우


// 삼항 조건 연산자 !!!!
// 조건 ? true일 때 실행 할 명령문 : false일때 실행 할 명령문

// small = (num1 < num2) ? num1 : num2;


// if (num1 < num2) {
//   samll = num1;
// } else {
//   small = num2;
// }

// ● 짝수 / 홀수 알려주기 
// let number = parseInt(prompt("숫자를 입력해 주세요", "ex) 52"))

// if(number%2 == 0) {
//   document.write("짝수입니다")
// }
// if(number%2 == 1) {
//   document.write("홀수입니다")
// }

// ● if 삼항문 !!!!
// let number = parseInt(prompt("숫자를 입력해 주세요", "ex) 52"));
// if (number !== null) {
//   (number % 2 ===0) ? alert("짝수입니다.") : alert("홀수입니다.")
// }

// switch문
// ============================================
// switch(조건) {
//   case 값 : 문장
//     break;
//   case 값 : 문장
//     break;
//   case 값 : 문장
//     break;
//   default
// }


// 스위치 예문 1
// let subject = prompt("신청 할 과목을 선택하세요 1. html / 2.css / 3. javascript")

// if(subject !== null) {
//   switch(subject) {
//     case "1" : document.write("html을 신청했습니다.");
//       break;
//     case "2" : document.write("css를 신청했습니다.");
//       break;
//     case "3" : document.write("javascript를 신청했습니다.");
//       break;
//       default : document.write ("잘못 입력했습니다 다시 입력해주세요")
//   }
// }

// 스위치 예문 2
// const num1 = parseInt(prompt("첫 번째 점수 : "));
// const num2 = parseInt(prompt("두 번째 점수 : "));

// let = str;

// if (num1 % 2 === 0 && num2 % 2 ===0) {
//   str = "두 수 모두 짝수입니다!"
// } else {
//   str = "짝수가 아닌 수가 있습니다"
// }
// alert(str);


// for문
// ============================================
// for (초기값; 조건식; 증감문;) {
//   반복 할 실행문
// }

// for 예제 1
// const students = ["park","kim", "lee", "kang"];

// for(let i = 0; i < students.length; i++) {
//   document.write(`${students[i]}, `)
// }

// for 예제 2
// let colors = ["mint","pink", "beige", "ivory"];

// for(let i = 0; i < colors.length; i++) {
//   document.write(`${colors[i]}. `)
// }


// ● 지금까지 배운 for 기본형!
// - forEach() 함수 : 배열객체에서 각각의 요소들을 꺼내서 반복시키고자 할 때
// - forEach(콜백함수)
// > 콜백함수란 : 다른 함수의 인자값으로 사용되는 함수를 의미합니다
// > 인자값 = 인수 : 매개변수의 값으로 적용 될 값
// > 매개변수 = function("매개변수") : 함수가 작동하기 위해서 존재해야하는 값

// - for in 문 : 일반객체에서 객체 안에 있는 프로퍼티(* key : value)을 가져와서 반복 시킬 떄



// forEach 예제 1
// const students = ["park", "lee","kim", "son"];

// students.forEach(function(student) {
//   document.write(`${student}. `);
// })

// forEach 예제 2
// let fruits = ["딸기", "샤인머스캣", "바나나", "체리"];

// fruits.forEach(function(fruit) {
//   document.write(`${fruit}. `)
// })

// for in 예제 1
// const bookInfo = {
//   title : "자바스크립트",
//   pubDate : "2023.04.11",
//   pages : 287,
//   finished : true
// }
// // for(변수 in 객체명)
// for(key in bookInfo) {
//   document.write(`${key} : ${bookInfo[key]}<br />`)
// }


// - for of문 : 문자열 혹은 배열객체에서 반복 가능한 반복문!

// for of 예제1
// const students = ["park", "son","lee", "kang"]
// for (el of students) {
//     document.write(`${el}. `);
// }

// for in : : 일반 객체에서 객체의 값을 가져와서 반복처리할 때 주로 사용

// for of : 배열객체에서 각각으 변수값을 가져와서 반복처리할 때 주로 사용 !! => for Each

//  - while : 조건이 참인 경우 문장을 반복

// while (조건) {
//   실행 할 명령
// }


// while 예제 1
// let stars = parseInt(prompt("별의 개수 : "));

// while (stars > 0) {
//   document.write("*");
//   stars--;
// }





//  - do while : 참, 거짓 여부와 상관없이 무조건 1회 반복 후 조건식을 참고 !

//  do {
//   실행 할 명령
//  } while (조건)

// do while 예제 1

// let stars = parseInt(prompt("별의 개수 : "));

// do {
//   document.write("*");
//   stars--;
// } while(stars > 0)

// do while은 무조건 실행을 해야하기 때문에 0을 찍어도 별 1개가 나타난다.



// - break문 : 반복문 강제종료 !!

// - continue문 : 특정조건에 해당되는 값을 만났을 때, 실행하던 반복문장을 건너뛴다!


// 소수란? 1과 자기 자신으로만 나눌 수 있는 숫자

// break문 예제 1 > 소수 판별식
// const number = parseInt(prompt("숫자를 입력하세요!"));
// let isPrime;

// if (number === 1) {
//   document.write(`${number}은 소수도, 합성수도 아닙니다.`);
// } else if (number === 2) {
//   isPrime = true;
// } else {
//   for (let i = 2; i < number; i++) {
//     if (number % i === 0) {
//       isPrime = false;
//       break;
//     } else {
//       isPrime = true;
//     }
//   }
// }

// if (isPrime) {
//   document.write (`${number}는(은) 소수입니다.`)
// } else {
//   document.write (`${number}는(은) 소수가 아닙니다.`)
// }


// const arr = [1, 3, 5, 7, 9, 11, 13, 15, 17, 19];

// for (let i = 0; i < arr.length; i++) {
//   if (arr[i] > 10) {
//     document.write(`${arr[i]}, `)
//   }
// }1


// 예제) 홀수를 1을 더해서 짝수로 만드는 문제
// let num = parseInt(prompt("1보다 큰 숫자를 입력 해 주세요"))
// let sum = 0;

// if(num !== null && num > 1) {
//   for(let i = 1; i<= num; i++) {
//     if (i % 2 === 1) {
//       continue;
//     }
//     sum += i;
//     document.write(`${i} ------${sum} </br>`)
//   }
// }

  // for(i = 1; i < num.legnth; i++) {
  //   if (num % 2 === 1) {
  //     document.write(`${num}는(은) 홀수입니다!`) 
  //     let sum = i +1
  //     } else if (num % 2 === 0) {
  //       document.write(`${num}는(은) 짝수입니다!`) 
  //     } 
  // }


// ● 함수 !!!!!!! 젤 중요한 함수 ^__________^
// 변수 : 바구니
// 객체 : 다양한 정보들의 집합체
// 함수 : 여러개의 명령들을 묶어놓은 것

// 함수를 사용해야하는 이유
// 1. 사용자의 요구사항이 천차만별이다
// 2. 함수의 생김새 => 함수이름()
// 3. 함수생성 = 함수선언
// 4. 객체생성 = 객체선언 (같은 표현이다)
// 5. 생성한 함수를 호출해야 함수를 사용할 수 있다 !
// 6. 함수는 어떻게 만들어지는가 ? 
// function 함수명() {
//   실행명령문
// }
// 함수명() => 함수 호출방법

// function calcSum() {
//   let sum = 0;
//   for(let i = 1; i <= 10; i++) {
//     sum += i;
//   }
//   console.log(`1부터 10까지 더하면 ${sum}입니다`);
// }

// calcSum();

// --------------------> 사용자로 하여금 특정 값을 받아서 함수를 실행 시키고자 할 때 매개변수가 필요합니다 ! ★★★★★★★★★★

// 매개변수에 전달 될 값 = 인수 혹은 인자값!


// function sum(매개변수) {

// }

// let a = parseInt(prompt("a값을 입력하세요"));
// let b = parseInt(prompt("b값을 입력하세요"));

// function sum(a, b) {
//   let result = a + b;
//   alert(`두 수의 합 : ${result}`)
// }


// function calcSum(n) {
//   let sum = 0;
//   for(let i = 1; i <= n; i++) {
//     sum += i;
//   }
//   console.log(`1부터 ${n}까지 더하면 ${sum}입니다.`)
// }

// calcSum(100)

// function calcSum(n) {
//   let sum = 0;
//   for (let i = 1; i <= n; i++) {
//     sum += i;
//   }
//   return sum;
// }

// let num = parseInt(prompt("몇까지 더할까요?"));
// document.write(`1부터 ${num}까지 더하면 ${calcSum(num)}입니다`);

// 함수에서 반환을 하는 방법 : return;

//  let a = parseInt(prompt("a값을 입력하세요"));
//  let b = parseInt(prompt("b값을 입력하세요"));

// //  let multiple = a*b
// //  document.write(`${a}x${b}는 ${multiple}입니다.`)

// function multiple(a, b) {
//     return a * b
//  }
//  document.write(`두 수를 곱한 결과는 ${multiple(a, b)}입니다`)


// 예제 문제
// function multiple(a, b, c) {
//   return a * b + c;
// }
// multiple(2, 4, 8);
// 16



// 예제 문제 = > 매개변수 기본값 지정하는 방법 !!!!!!!!!
// function multiple(a, b = 5, c = 10) {
//   return a * b + c;
// }
// console.log(multiple(5, 10, 20));
// console.log(multiple(10, 20));
// console.log(multiple(10));


// 예제 문제 = > calcSum 함수 사용하기
// function calcSum(n) {
//   let sum = 0;
//   for (let i = 1; i <= n; i++) {
//     sum += i;
//   }

//   console.log(`1부터 ${n}까지 더하면 ${sum}입니다.`)
// }

// calcSum(10);

// 함수 디버깅 하는 방법!
// 브라우저에서 ctrl + shift + i 눌르고 브레이킹포인트 (함수 호출) 눌러서 확인

// 함수 스코프 = 적용범위
// > 어떠한 함수가 영향을 미칠 수 있는 적용 범위

// 1. 지역 스코프 = Local
// > 지역변수

// 2. 전역 스코프 = Global
// > 전역변수

// 전역변수를 사용하는 방법 !!
// 1. 코드를 작성 할 때 , 가장 최상단에 변수를 선언하고 값을 할당한다
// 2. 함수 안에 변수를 작성 할 때, 변수를 정의하는 키워드 = 예약어를 생략한다

// ex 1 ) 
// let hi = "hello"

// function change() {
//     hi = "bye";
// }
// console.log(hi);
// VM881:6 hello
// change();

// console.log(hi);
// 1 bye



// ex 2 > 함수의 매개변수 값을 넣고 인자값을 넣어준다 !

// const factor = 5;

// function calc(num) {
//     return num * factor;
// }

// {
//     let result = calc(10);
//     document.write(`result : ${result}`);
// }

// 스코프 = 영역 범위

// 1. 지역스코프
// 2 .전역스코프
// 3. 블록스코프


// function addSum(n) {
//   var sum = 0;
//   for (var i = 1; i <= n; i++) {
//     sum += i;
//   }
//   return sum;
// }
// var num = 3;
// console.log(`1부터 ${num}까지 더하면 : ${addSum(num)}`);


// function addSum(n) {
//   let sum = 0;
//   for (let i = 1; i <= n; i++) {
//     sum += i;
//   }
//   return sum;
// }
// const num = 3;
// console.log(`1부터 ${num}까지 더하면 : ${addSum(num)}`)

// var 특징 문서객체 모델이 아니라 브라우저 객체 모델에 영향을 시킬 수 있다!

// let은 재선언, 재할당이 안된다 !


// ● 익명함수 : 함수이름을 정의하지 않는 함수, 변수가 함수명을 대체함
// 형태 :
// let sum (* 참조변수) = function(a, b) {

// }

// 자바스크립트 함수 => 1급 함수
// 함수를 익명으로 선언 / 함수를 변수값으로 할당


// ● 즉시 실행 함수 !! : 함수를 정의하면서 동시에 실행시키는 함수
// 즉시 실행 함수 형태 : 
// (function (매개변수) {

// }, (인자값))

// 예제 )
// (function(a, b) {
//   let sum = a+ b;
//   console.log(`함수 실행 결과 ${sum}`)
// }(100, 200));
// VM539:3 함수 실행 결과 300

// ● 화살표 함수 쓰는 이유 :
// 1. 매개변수가 없을 때


// 1) [매개변수가 없을 때 화살표 함수 사용법]
// let hi = function() {
//   return `안녕하세요!`;
// }

// 2)
// let hi = () => { return `안녕하세요`};

// 3)
// let hi = () => `안녕하세요`;

//4) [매개변수가 하나 일 때, 화살표 함수 사용법]
// let hi = function(user) {
//   console.log(`${user}님 안녕하세요`);
// }
// hi('민정');

//5) 
// let hi = user => console.log(`${user}님 안녕하세요`);
// hi('민정')

//6) [매개변수가 2개 이상 일 때, 화살표 함수 사용법]
// let sum = function(a, b) {
//   return a + b;
// }
// sum(10, 20);

//7)
// let sum = (a , b) => a+b;
// sum(10, 20)
// 30

// 콜백함수
// 콜백함수 > 함수안에 인수가 되는 또다른 함수

// const btn = document.querySelector("button");

//일반 함수 쓸 때!
// function display() {
//   alert("클릭했습니다.")
// }

//화살표 함수 쓸 때!
// btn.addEventListener("click",() => {
//   alert("클릭했습니다.")
// })

//display가 콜백함수이다


// 콜백함수 예제! 두수 받아서 곱셈값 받아오기 => 화살표함수 사용
// let a = parseInt(prompt("a값은?"));
// let b = parseInt(prompt("b값은?"));


// let multiple = (a, b) => a * b

// document.write(`결과값은 ${multiple(a, b)}입니다`)


// function showData(name, age) {
//   alert(`안녕하세용 ${name}님 나이가 ${age}살 이군요!`);
// }

// function getData(callback) {
//   let userName = prompt("이름을 입력하세요!");
//   let userAge = parseInt(prompt("나이를 입력하세요"));
//   callback(userAge, userName);
// }

// getData(showData);

/// ...을 이용하여 숫자 더하기 
// function addNum(...numbers) {
//   let sum = 0;

//   for (let number of numbers)
//       sum += number;
//   return sum;
// }
// console.log(addNum(1, 3)); //4가 나옴!
// console.log(addNum(4, 5, 6, 7,)); // 22가 나옴!


// first, ...favs 두개는 순서가 바뀌면 안됌!
// function displayFavorit(first,...favs) {
//   let srt = `가장 좋아하는 과일은? "${first}" 군요!`;
//   return srt;
// }

// console.log(displayFavorit("사과", "포도","토마토"));




// ● setInterval()

// > 사용법 : setInterval(콜백함수, 시간)
// > 일정한 시간마다 함수를 반복해서 실행하는 함수
// > 자바스크립트는 밀리초를 사용한다 1000밀리초 = 1초

 // 예제1
//  function greeting() {
//   console.log("안녕") 
//  }
//  setInterval(greeting, 2000)

 // 예제 1 축약버전
// setInterval(() => {console.log("안녕")}, 2000);


// 익명함수를 사용하여 clearInterval함수 사용하기
// let timer =setInterval(() => {console.log("안녕")}, 2000);
// clearInterval(timer);


// 2초동안 안녕하세요 반복실행하고 5번되면 종료 시키키
// let counter = 0;

// let timer = setInterval(() => {
//   console.log("안녕하세요!")
//   counter++;
//   if (counter === 5)
//   clearInterval(timer)
// }, 2000);



// setTimeout : 일정시간 이후에 콜백함수를 실행 !!
// setTimeout(콜백함수, 3000);

// setTimeout(() => {
//   console.log("안녕하세요!")
// }, 3000)




// isNaN(매개변수) : 매개변수가 숫자인지 아닌지를 검사하는 함수!
// > 매개변수가 숫자가 아니면, true 숫자이면 false

// const number = parseInt(prompt("숫자를 입력해주세요"));

//   if (!isNaN(number)) {  
//     isPositive(number);
//   } 
//   function isPositive(number) {
//     if (number > 0) {
//       alert ("양수입니다.")
//     } else if (number < 0) {
//       alert("음수입니다.")
//     } else {
//       alert("0 입니다.")
//     }
//   }



// 예제) 두 수를 받아서 최대 공약수를 구하시오
  // const first = parseInt(prompt("숫자를 입력해주세요"));
  // const second = parseInt(prompt("숫자를 입력해주세요"));

  // 1. 두 숫자가 특정값에 동일하게 나누어져야한다.
  // 2. 그 특정값 중에서 가장 큰 값을 찾아야한다.

// function getGCD(n, m) {
//   let max = n > m ? n : m //삼항조건 > 큰 값 구하는 공식 !!!!
//   let GCD = 0; 
//   for (let i = 1; i <= max; i++) {
//     if (n % i === 0 && m % i === 0) {
//       GCD = i; //공약수
//     }
//   }
//   return GCD
// }
// document.write(`${first}와(과) ${second}의 최대 공약수는 : ${getGCD(first, second)}`)

// ● 텍스트 input 태그 필드에 입력한 값 가져오기!!
// 선택요소.value

// 만약 id값과 class값이 없다면?
// > name을 활용해서 값을 가져 올 수 있다.
