// ★★ 예제문제 : 새로고침 시 이미지 랜덤으로 불러오기
// 1. 출력할 공간 정의
// 2. 출력할 요소 -> 컨텐츠에 대한 정의

// 첫번째 방법
// const changeBg = () => {
//   const bgCount = 5;
//   let randomNum = Math.ceil(Math.random() * bgCount);

//   document.body.style.backgroundImage = `url(img/bg-${randomNum}.jpg)`
// }
// document.onload = changeBg();

// 두번째 방법
// window.onload = function() {
//   const bgCount = 5;
  
//   let randomNum = Math.ceil(Math.random() * bgCount);
//   document.body.style.backgroundImage = `url(img/bg-${randomNum}.jpg)`
// }


// ★★ 예제문제 : 내가 살아온 시간


// 1. 버튼에 대한  기능 정의 > 이벤트
// 2. 사용자로부터 값을 입력 받고 저장할 수 있는 공간에 대한 정의
// 3. 원하는 값을 출력해야하는 공간에 대한 정의
// 4. 출력할 값에 대한 수식 정의


// const btn = querySelector("#btn")
// let birthYear = document.querySelector("#year").value; 
// let birthMonth = document.querySelector("#month").value; 
// let birthDate = document.querySelector("#date").value;



// btn.addEvnetnLister("click", function() {

// });

// const today = new Date();
// const nowYear = today.getFullYear();
// const nowMonth = today.getMonth()+1;
// const nowDate = today.getDate();
// const nowDay = today.getDay();
// const h = today.getHours();
// const m = today.getMinutes();

// const todayTime = today.getTime();
// let birthTime = birthDay.getTime();

// document.querySelector("#result").innerHTML = (`${nowYear}년 ${nowMonth}월 ${nowDate}일 ${h}시 ${m}분 현재`)



const btn = document.querySelector("#btn")
let birthYear = document.querySelector("#year");
let birthMonth = document.querySelector("#month");
let birthDate = document.querySelector("#date");

const current = document.querySelector("#current");
const resultDays = document.querySelector("#days");
const resultHour = document.querySelector("#hour");
const resultYears = document.querySelector("#years");

const today = new Date();
current.innerHTML = `${today.getFullYear()}년 ${today.getMonth()+1}월 ${today.getDate()}일 ${today.getHours()}시 ${today.getMinutes()}분 현재`


btn.addEventListener("click", function(e) {
  e.preventDefault();
  const birthDay = new Date(birthYear.value, birthMonth.value - 1, birthDate.value);

  let passed = today.getTime() - birthDay.getTime();
  let passedYear = Math.floor(passed / (1000 * 60 * 60 * 24 * 365));
  let passedDays= Math.floor(passed / (1000 * 60 * 60 * 24));
  let passedHours = Math.floor(passed / (1000 * 60 * 60));

  resultYears.innerHTML = (`년도로는 ${passedYear}이 흘렀습니다.`)
  resultDays.innerHTML = (`날짜로는 ${passedDays}일이 흘렀습니다`)
  resultHour.innerHTML = (`날짜로는 ${passedHours}일이 흘렀습니다`)
});