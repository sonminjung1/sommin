const btn = document.querySelector("button");
const popWidth = 600;
const popHeight = 500;

btn.addEventListener("click", function() {
  let left = (screen.availWidth - popWidth) / 2;
  let top = (screen.availHeight - popHeight) / 2;
  // 팝업을 정중앙에 오게하는 계산법!!!!!!!
  
  window.open("popup.html", "pop1", `width=${popWidth} height=${popHeight} left=${left} top${top}`);
})