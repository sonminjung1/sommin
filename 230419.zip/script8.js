// 컴퓨터와 게임하는 가위바위보 게임 만들기 :)

// 1. 버튼에 대한 정의가 필요 (*가위 바위 보에 따라서 어떠한 값을 부여할 것인가?)

// 2. 컴퓨터 선택에 대한 정의 (Math 객체를 활용해서 값을 부여)

// 3. 컴퓨터와 사용자 선택값에 대한 우열을 가릴 수 있는 조건식 정의!!!!

// 4. 컴퓨터와 사용자 선택값에 따른 결과를 출력 할 공간에 대한 정의 

const buttons = document.querySelectorAll("button");
const computerChoice = document.querySelector(".computer-choice");
const userChoice = document.querySelector(".you-choice");
const winner = document.querySelector(".result");

const show = (user, computer, result) => {
  computerChoice.innerHTML = computer;
  userChoice.innerHTML = user;
  winner.innerHTML = result;
}

const result = ["가위", "바위", "보"];
const game = (user, computer) => {
  if (user == computer) {
    massage = "무승부"
  } else {
    switch (user + computer) {
      case '가위보' :  
      case '바위가위' :
      case '보바위' :
        massage = "사용자 승리"
        break;
      case '가위바위' :
      case '바위보' :
      case '보가위' :
        massage = "컴퓨터 승리"
        break; 
    }
  }
  show(user, computer, massage);
};

const play = (event) => {
  const user = event.target.innerText
  const randomIndex = Math.floor(Math.random() * result.length);
  const computer = result[randomIndex];
  game(user, computer);

}
buttons.forEach((buttons) => {
  buttons.addEventListener("click", play)
})
