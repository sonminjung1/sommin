//  ★★★ 내장객체 ★★★

// window 객체 : pageX / pageY : 화면상에 마우스가 이동했을 때의 키값을 반환하는 프로퍼티

// > screen 객체 : .innerWidth / .width
// > navigator 객체 : userAgent
// > location 객체 : .reload()

// Date 객체 : 현시점의 년도, 월, 일, 날짜, 요일, 시간 등을 사용하고자 할 때 이용하는 내장객체

// > 내장되어있는 Date 객체를 사용하는 방법 :
// = const today = new Date()
// today = 인스턴스 객체라고 부름 > 자주 사용하는 객체를 만들어내는 것
// 자바스크립트 시간 세계관 ★
// 1초 > 1000밀리초
// 1분 > 60 * 1000
// 1시간 60 * 60 * 1000밀리초
// 1일 24 * 60 * 60 * 1000밀리초  




// 사용기기에 따라서 이미지가 바뀌는 예제 ★★★★
// let inpo = navigator.userAgent.toLowerCase();

// let osImg = null;

// if (info.indexOf('windows') >= 0) {
//   osImg = 'windows.png'
// } else if (inpo.indexOf('macintosh') >= 0) {
//   osImg = 'macintosh.png'
// } else if (info.indexOf('iphone') >= 0) {
//   osImg = 'iphone.png';
// } else if (info.indexOf('android') >= 0) {
//   osImg = 'android.png'
// }

// document.write("<img> src=\"/img/"+ osImg +"\">", "<br>");
// let src = screen;
// let sc_w = src.width;
// let sc_h = src.height;

// document.write("모니터 해상도 너비 : " + sc_w + "px", "<br>")

// 위에 안됌 ㅋ



// location.reload 예제 문제 ★★★★
// let id = "today"
// let pw = 1234;

// let user_id = prompt("당신의 아이디는?");

// if(id == user_id) {
//   let user_pw = parseInt(prompt("당신의 비밀번호는?"));
  
//   if(pw == user_pw) {
//     document.write(user_id + "님 반갑습니다.")
//   } else {
//     alert("비밀번호가 일치하지 않습니다.")
//     location.reload(); // 새로고침해서 다시 시작하게해주는 함수
//   }
// } else {
//   alert("아이디가 일치하지 않습니다.");
//   location.reload(); // 새로고침해서 다시 시작하게해주는 함수
// }


// 마우스 움직이기!!!!!!!!!
// let pointSize = $('.pointer').width();
// $('#wrap').mousemove(function(e) {
//   $('.pointer').css("top", e.pageY-pointSize);
//   $('.pointer').css("left", e.pageX-pointSize);
//   $(".pointer").fadeIn();
// });

// $("#wrap").on("mouseleave", function() {
//   $(".pointer").fadeOut();
// })


// 날짜 시간 
// let theDay1 = new Date(2023-03-09);
// let theDay2 = new Date(2023,03,09);
// let theDay3 = new Date("02/28/2023"); // 외국식 표기법


// 이것만 알면 된다 ^^
// toDateString() : Date에서 날짜 부분만 표시할 때
// toTimeString() : Date에서 시간 부분만 표시할 때

// 특정 날짜 데이터를 사용하고자 할 때, 월(month)의 값만 1이 아닌 0에서 시작합니다.
// ex) 4월 = 3월
// 그러므로 +1해서 계산에서 가져와야한다.


// 날짜 정보 가져오는 예제!!!!!!!!
// let today = new Date();
// let nowMonth = today.getMonth()+1;
// let nowDate = today.getDate();
// let nowDay = today.getDay();

// document.write("<h1>오늘 날짜 정보</h1>");
// document.write("현재 월 :"+nowMonth, "<br>")
// document.write("현재 일 :"+nowDate, "<br>")
// document.write("현재 요일 :"+nowDay, "<br>")


// let classOpen = new Date("2023-02-28");
// let theMonth = classOpen.getMonth()+1;
// let theDate = classOpen.getDate();

// document.write("<h1>개강일</h1>");
// document.write("현재 월 :"+theMonth, "<br>")
// document.write("현재 일 :"+theDate, "<br>")




// let today = new Date();
// let nowYear = today.getFullYear();

// let theDate = new Date(nowYear, 11, 31);
// // 월만 인덱스 값을 가져오기 때문에 기준점 달을 -1을 불러와야함 ....
// let diffDate = theDate.getTime() - today.getTime();

// let result = Math.ceil(diffDate / (60 * 60 * 24 * 1000));
// document.write("연말 D-day :" + result + "일 남았습니다.")

// ★★★ 디데이 만들기 예제문제!!!!!!!!!!!!!!!!

// 처음 만난 날
let now = new Date();
let firstDay = new Date("2023/02/28");

let toNow = now.getTime();
let toFirst = firstDay.getTime();

let passedTime = toNow - toFirst;
let passedDay = Math.ceil(passedTime/(60 * 60 * 24 * 1000));
document.querySelector('#accent').innerText = passedDay + "일"

// ★ D-day Function ★
function calcDate(e) {
  let future = toFirst + e*(60 * 60 * 24 * 1000);
let someDay = new Date(future);
let year = someDay.getFullYear();
let month = someDay.getMonth() +1;
let date = someDay.getDate();
document.querySelector("#date"+e).innerHTML = year + "년" + month + "월" + date + "일"
}
//이건 호출문 (인자값!)
calcDate(100);
calcDate(200);
calcDate(365);
calcDate(500);
