// 1. 추첨 및 지우기 버튼에 대한 기능 정의
// 2. 입력한 값에 대한 저장 공간 및 활용에 대한 기능 정의
// 3. 입력한 값을 출력할 공간에 대한 정의
// 4. 출력할 값에 대한 조건 및 논리구조 정의

const raffle = document.querySelector("#raffle");
// const reset = document.querySelector("#reset");

raffle.addEventListener("click", function(e) {
  e.preventDefault();
  const seed = document.querySelector("#seed");
  const total = document.querySelector("#total");
  const result = document.querySelector("#result");
  let winner = "";

for(let i = 0; i < total.value; i++) {
    let picked = Math.ceil(Math.random() * seed.value);
    winner += `${picked}번 `
  }
  result.innerText = `당첨자 : ${winner}`
})