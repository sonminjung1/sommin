// ★★ 디지털 시계 만들어보긔 ★★ 

// const hour = document.querySelector(".hour")
// const min = document.querySelector(".min")
// const sec = document.querySelector(".sec")

// function clock() {
//   const now = new Date();

//   hour.innerHTML = now.getHours();
//   min.innerHTML = now.getMinutes();
//   sec.innerHTML = now.getSeconds();
// }

// setInterval(clock, 1000);



// ★★ 아날로그 시계 만들어버기리~ ★★ 
// setInterval(()=> {
//   const now = new Date();

// const h = now.getHours();
// const m = now.getMinutes();
// const s = now.getSeconds();

// const degH = h * (360 / 12) + m * (360 / 12 / 60);
// const degM = m * (360 / 60);
// const degS = s * (260 / 60);

// const elementH = document.querySelector('.lineHour');
// const elementM = document.querySelector('.lineMin');
// const elementS = document.querySelector('.lineSec');

// elementH.style.transform = `rotate(${degH}deg)`;
// elementM.style.transform = `rotate(${degM}deg)`;
// elementS.style.transform = `rotate(${degS}deg)`;

// })


