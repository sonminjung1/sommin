// 웹 브라우저의 최상위 객체 = window

// 콘솔창에 window를 쳤을때 많은 기능들 중에서 f가 안붙여져있는건 window의 하위객체이다.

// alert("좋은아침~")
// prompt("아침 드셨나요")
// confirm("정말로 개발자가 되고싶나요?")



// <img src="/img/iu.jpg" alt="iu" usemap="#intro">
{/* <map name="intro">
  >> 좌표값을 주는 이벤트를 걸기 위한 방법 */}

  // window.open("popup.html", "popup1","width=320, height=450, left=50, top=20");

  
  // 팝업을 뜨게하기 위해선 html 주소, 팝업 이름, 팝업 사이즈를 꼭 적어여함 > 맨 뒤에는 팝업 위치까지 설정할 수 있다!


  // 두번째 팝업창
  window.open("popup.html", "이벤트 팝업", "width=600 height=500 left=300 top=200")