// // 수학 객체 > 메서드 24개 > 18개

// let num = 2.1234;
// let maxNum = Math.max(10, 5, 8, 30); // 가장 최댓값
// let minNum = Math.min(10, 5, 8, 30); // 가장 최소값
// let roundNum = Math.round(num);
// let floorNum = Math.floor(num);
// let ceilNum = Math.ceil(num);
// let randomNum = Math.random(); // 이 아이가 핵심이다 ..
// let piNum = Math.PI;

// document.write(maxNum, "<br>");
// document.write(minNum, "<br>");
// document.write(roundNum, "<br>");
// document.write(ceilNum, "<br>");
// document.write(randomNum, "<br>");
// // 랜덤값은 1이 넘지 않는다★★★★ 이러한 실수를 랜덤으로 비규칙적인 값으로 반환한다.
// document.write(piNum, "<br>");

// ★★ 수학 객체 예제 문제 ★★
// let menu = ["짜장밥", "돈까스", "국밥", "쌈밥", "회덮밥", "김치찌개"];
// let menuNum = Math.floor(Math.random()*menu.length);
// // length = 매번 숫자를 바꿀 수 없으므로 .length를 가져와야함!!!!!!
// let result = menu[menuNum]

// document.write(result);

// ★★ 가위바위보 게임 ★★
let game = prompt("가위 바위 보 선택하세요!","가위");
let gameNum;

switch (game) {
  case "가위" :
    gameNum = 1; break;
  case "바위" :
    gameNum = 2; break;
  case "보" :
    gameNum = 3; break;
  
  default : alert("잘못 입력하셨습니다.")
  location.reload();
}

let com = Math.ceil(Math.random()*3);
document.write("<img src=\"/img/math_img_"+ com +".jpg\">");

if(gameNum == com) {
  document.write("<img src=\"/img/game_1.jpg\">");
} else {
  document.write("<img src=\"/img/game_2.jpg\">");
}