// 1. createElement() : 요소(*태그) 노드 만들기
// 2. createTextNode() : 텍스트 노드 만들기
// 3. appendChild() : 부모요소에 자식요소로 연결하기
// 4. createAttribute() : 속성 노드 만들기
// 5. setAttributeNode() : 속성 노드 연결하기

// ★★ 바디태그에 이미지 불러오기 예제문제 ★★
// let newImg = document.createElement("img");
// let srcNode = document.createAttribute("src");
// srcNode.value = "/img/sohee.jpg";

// newImg.setAttributeNode(srcNode);
// document.body.appendChild(newImg);



let newImg = document.createElement("img");
let 