// 모든 html 태그는 요소 노드가 됩니다.
// html 태그에서 사용하는 텍스트 내용은 자식노드 ex) h1에서 텍스트
// html 태그에서 속성은 모두 자식노드

// * 노드 리스트!!!
// queryselector() : 단일 요소를 선택
// queryselectorAll() : 복수 요소를 선택


// * 기존에 없던 새로운 노드를 만들어서 추가하고 싶은 경우!!!!
//  > document.createElement(생성하고싶은 요소명)

// 콘솔창 예시
// let newP = document.createElement("p");
// let textNode = document.createTextNode("Typescript");
// newP.appendChild(textNode);
// 부모노드.appendChild(자식노드)




// ★★ 문제 풀어보기 ★★ 주문하기 클릭 시 상품명 출력하기 ★
// 1. 주문하기 라는 버튼 정의
// 2. 아래에 내용이 나와야하는 출력공간 정의
// 3. 출력 공간에 보여줄 컨텐츠 정의

const orderBtn = document.querySelector("#order");
const orderInfo = document.querySelector("#orderInfo");
const title = document.querySelector("h2");


orderBtn.addEventListener("click", function() {
  let newP = document.createElement("p");
  let textNode = document.createTextNode(title.innerText);

  newP.appendChild(textNode);
  newP.style.fontSize  = "0.8em";
  newP.style.color  = "blue";
  orderInfo.appendChild(newP);
}, {once : true}); // 함수가 한번만 실행하도록! once : true 기억하기



// ★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★
// 1. createElement() : 요소(*태그) 노드 만들기
// 2. createTextNode() : 텍스트 노드 만들기
// 3. appendChild() : 부모요소에 자식요소로 연결하기
// 3. createAttribute() : 속성 노드 만들기
// 3. setAttributeNode() : 속성 노드 연결하기