let name = document.querySelector("#name");
let major = document.querySelector("#major");
const save = document.querySelector("#save");
const result = document.querySelector("#attendant")

save.addEventListener("click", function(e) {
  e.preventDefault();



  let tbody = document.querySelector("tbody")
  let newTr = document.querySelector("tr")

  let nameTd = document.createElement("td");
  nameTd.innerText = name.value;;

  let majorTd = document.createElement("td");
  majorTd.innerText = major.value;

  newTr.appendChild(nameTd)
  newTr.appendChild(majorTd);

  tbody.appendChild(newTr);



name.value = '';
major.value = '';

});