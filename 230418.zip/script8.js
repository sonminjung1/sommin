// 1. 버튼 클릭 시 응원메세지가 나오고 3초뒤에 사라지게 하기
// createElement / classList / setTimeout

const btn = document.querySelector("#button");
const notiBox = document.querySelector("#noti-box");

btn.addEventListener("click", function() {

  let noti = document.createElement("div");
  noti.classList.add('noti');
  noti.innerText = "항상 응원합니다";
  notiBox.appendChild(noti);

  setTimeout(() => {
    noti.remove()
  }, 3000)
});