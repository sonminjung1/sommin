const items = document.querySelectorAll("span");

for(item of items) {
  item.addEventListener("click", function() {
    this.parentNode.remove(this);
  });
}