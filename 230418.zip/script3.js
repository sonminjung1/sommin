// 시간에 따라서 이미지가 변경되는 예제 문제 (오전 / 오후 이미지 변경)

// 논리적으로 생각해보기
// 1. 시간의 개념 정리 (오전 . 오후)

// 2. 시간 변화에 따라서 출력해줘야하는 이미지를 정의
// > 시간 변화 정의를 먼저하고, 이미지를 정의

// 3. 이미지를 출력 할 공간에 대한 정의

const container = document.querySelector("#container");
const today = new Date();
const hrs = today.getHours();

//시간에 따른 이미지 정의 > 삼항조건
let newImg = document.createElement("img")
newImg.src = (hrs < 12) ? "/img/morning.jpg" : "/img/afternoon.jpg"

container.appendChild(newImg)

// 날씨에 따라 이미지가 변경되는 걸 포트폴리오에서 사용할 수 있다!!!!!
// 제이슨 > 기상청 