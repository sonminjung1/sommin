// 북리스트 만들기 미니 프로젝트 ^_^

// 1. 제목, 저자에 대한 데이터 공간 및 정의가 필요하다.
// 2. 취소하기 및 저장하기 버튼 내용 정의
// 3. 삭제하기 버튼 내용 정의
// 4. 입력된 데이터가 출력 될 공간에 대한 정의가 필요하다.

let title = document.querySelector("#title");
let author = document.querySelector("#author");
const save = document.querySelector("#save"); 
// 여기서 포인트 ! 취소하기는 나중에 해야함 !
const bookList = document.querySelector("#bookList");

// 기본적으로 버튼을 누르면 날라가는 기본이 깔려있다. 그러므로 
// 매개변수를 주고 preventDefault 줘야함!!!!
save.addEventListener("click", function(e) {
  e.preventDefault();

  const item = document.createElement("li");
    // innerText를 사용하면 태그까지 텍스트로 나오므로 innerHTML써야함
  item.innerHTML = `
  ${title.value} - ${author.value}
  <span class= "delButton">삭제</span>
  `;
  bookList.appendChild(item);

  title.value = ''
  author.value = ''
  // 인풋에 텍스트 적고 저장하기를 누르면 빈공간이 되게 만드는 것

  const delButtons = document.querySelectorAll(".delButton")
  for(let delButton of delButtons) {
    delButton.addEventListener("click", removeItem)
  }
});
// 콜백함수 사용하기
function removeItem() {
  let list = this.parentNode;
  list.parentNode.removeChild(list);
}