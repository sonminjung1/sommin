// 노드를 만들어서 자녀요소로 추가!
// 가장 마지막 영역에 추가 !!
// appendChild() : 부모요소에 가장 마지막 위치로 자녀를 편입시킴!


// ** 기존 노드의 앞에 새 요소로 추가하고자 할 때 사용하는 메서드 함수:
// insertBefore > 앞에 추가하고자 하는 요소, 기준점이 되는 요소

// 예제문제!
// let tsNode = document.createElement("p");
// let tsTextNode = document.createTextNode("Typescript");
// tsNode.appendChild(tsTextNode);

// let basisNode = document.querySelectorAll("p")[0];
// document.body.insertBefore(tsNode, basisNode);



// 텍스트 추가 버튼 클릭 시 javascript 텍스트 앞에 typescript 라는 단어가 추가 되도록 소스코드를 작성 해 보세요!

// 논리적으로 생각해보기
// 1. 텍스트추가 라는 버튼에 정의
// 2. 추가하고자 하는 컨텐츠에 대한 정의
// 3. 해당 컨텐츠가 출력되어야 하는 공간에 대한 정의


// const btn = document.querySelector("button")

// btn.addEventListener("click", function() {
//   let tsNode = document.createElement("p"); //P태그 추가하기
//   let tsTextNode = document.createTextNode(" *추가 TYPESCRIPT "); 
//   // 추가 할 텍스트 불러오기! > createTextNode
//   tsNode.appendChild(tsTextNode);
// // 텍스트를 p태그의 자식요소로 만들어줘야한다.

//   let basis = document.querySelectorAll("p")[2]; 
//   document.body.insertBefore(tsNode, basis);
// });



// ★★ 노드를 추가하거나 생성하거나 편입 시키는 메서드
// 노드 삭제하는 메서드
// > remove(): 
// 삭제하고자 하는 요소.remove() > 그냥 아예 삭제가 됌

// 리무브 예제 !! > h1 누르면 삭제되게 만들어보기 ★★
// const title = document.querySelector("h1"); //삭제하고자 하는 요소를 먼저 변수로 정의하기

// title.addEventListener("click", function() {
//   title.remove();
// });


// > remove(): 선택된 요소 및 노드 자체를 삭제합니다.
// > removeChild(): 선택된 요소 및 노드의 자녀 노드를 삭제합니다.

// * 부모노드를 찾는 프로퍼티 (= 속성)
// 자녀노드.parentNode => 해당 자녀노드의 부모노드를 찾아준다.(내 부모는 누구인가?!)
// ex) document.querySelector("h1").parentNode; ★★

// 부모노드.removeChild(자녀노드)



// ★ 예제문제 !! li 텍스트 클릭 시 삭제 시키기
// const items = document.querySelectorAll("li")
// // for of문 개념 확실하게 알기!!!!!!!!!!!! ★★ 제발좀
// for(let item of items) {
//   item.addEventListener("click", function() {
//     this.parentNode.removeChild(this);
//   });
// }; 

// ★ 주의 ★ 위에 구문은 화살표 함수를 사용하면 작동이 안된다!
