// 1. 이름 데이터를 보관한다 > ${userName.value}
// 2. 학과 데이터를 보관한다 > selectSub.options[selectSub.selectedIndex].innerText;

// 3. 다크모드 클릭 시 라이트 & 다크



// 토글버튼 !

// function darkMode() {
//   let body = document.body
//   body.onclick = () => {
//     body.classList.toggle("click")
//   }

//   let btn = document.querySelector("button");
//   if(btn.innerHTML == "Dark Mode") {
//     btn.innerHTML = "Light Mode"
//   } else {
//     btn.innerHTML = "Dark Mode"
//   }
// }



// 토글버튼 이렇게하는게 더 낫다 !
const selectSub = document.querySelector("#option");
const userName = document.querySelector("#userName")
const btn = document.querySelector("button")

function displaySelect() {
  let selectedText = selectSub.options[selectSub.selectedIndex].innerText;
  alert(`${userName.value}님, ${selectedText} 선택했습니다!`)
}
selectSub.onchange = displaySelect



btn.onclick = () => {
  document.body.classList.toggle("click");
  if(btn.innerHTML === "Dark Mode") {
    btn.innerHTML = "Day Mode";
  } else {
    btn.innerHTML = "Dark Mode"
  }
}

