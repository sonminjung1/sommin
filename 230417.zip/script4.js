//currentTarget이란 ? 
// 이벤트에 선택된 상위 요소
// target이랑 currentTarget 차이점 개념 알기

// const elements = document.querySelectorAll("*");
// // for(변수 of 객체)
// for(let el  of elements) {
//   el.addEventListener("click", function(e) {
//     console.log(`e.target : ${e.target.tagName}, e.currentTarget : ${e.currentTarget.tagName} `), false
//   });
// }

