// 이벤트 : 웹 브라우저 안에서 사용자가 실행하는 모든 동작

// 1. 문서 로딩 이벤트
// : 특정 문서를 불러올 때 사용하는 이벤트
// ex) 문서를 모두 불러온 이후에 어떤 함수 실행 !





// 2. 마우스 이벤트
// : 클릭 / 더블클릭 / 마우스 포인터가 특정 위에 있을때 또는 벗어났을 때 / 포커스 / 블러

// 3. 키보드 이벤트
// : 키를 눌렀을 때, 키에서 손을 뗄 때, 키를 누르고 있는 동안

// 4. 폼 이벤트
// : 특정 폼 요소에 포커스 / 블러
// : 목록 혹은 체크 상태가 변경


// window.onload = alert("안녕하세요!")
// // > 왜 굳이 document를 사용하지 않나 ?

// load : 특정 문서의 로딩이 끝났을 때, 어떠한 결과를 보여주는 이벤트

// > on이라는 키워드 + 이벤트 = 이벤트 핸들러라고 부른다
// > 이벤트 핸들러란 ? 이벤트가 발생하면 이벤트의 맞는 연결동작이 필요하는데, 이런 이벤트 연결동작을 처리하는 것


// ★ 마우스 클릭 이벤트 예시 ★
// const button = document.querySelector("button");

// button.onclick = () => {
//   document.body.style.backgroundColor = "green"
// }



// ★ 키보드 이벤트 예시 ★
// 1. 키보드에 어떤 키를 클릭했을 때, 해당 키를 출력할 공간
// 2. 어떤 키를 눌렀는지에 대한 정의 값
// * 키보드 이벤트  > 문서객체 > body 태그

// const body = document.body;
// const result = document.querySelector("#result");

// body.addEventListener("keydown", (e) => {
//   result.innerText = 
//   `code : ${e.code},
//   key : ${e.key}`;
// });


// 자바스크립트에서 이벤트가 작동될 수 있는 2가지 방법!!!

// 1. html 태그에 직접 함수를 연결하는 방법
// > <태그 이벤트핸들러 = "함수명">
// 이벤트핸들러 : on키워드 + 이벤트명
// ex)  <button onclick="alert('클릭')">Click</button>
// > 간단한 함수이거나 내장함수인 경우에 쓰임


// >> 문제점은 ?
// 1. 복수의 이벤트를 적용하고 싶은 경우
// ex) 배경색 / 팝업창 / 글자변경을 동시에 하고싶을 때 html 태그에 넣는 경우, 한계가 있다.

// 2. 자바스크립트에서 정의한 함수를 활용해서 html에 연결한 경우, 자바스크립트에 들어가서 함수명 수정 및 변경해야되므로 이중으로 일을 해야한다 ...

// 2. 자바스크립트에서 직접 함수를 연결하는 방법
// > 선택요소 (*이벤트를 주고싶은 요소).이벤트 핸들러 = 함수


// > 첫번째 방법!!!!
// const button = document.querySelector("button");

// button.onclick = () => {
//   document.body.style.backgroundColor = "green"
// }

// > 두번째 방법!!! 사전에 함수를 정의한 것.
// function changeBack() {
//   document.body.style.backgroundColor = "green"
// }
// const button = document.querySelector("button");
// button.onclick = changeBack;


// ★★ 테스트 문제 바탕화면에 클릭 버튼을 클릭하게 되면
// 바디태그 배경색은 #222로 color값은 #fff로 변경하세요!

// const button = document.querySelector("button");

// button.onclick = () => {
//   document.body.style.backgroundColor = "#222"
//   document.querySelector("p").style.color = "#fff"
// }


// 버튼 클릭 시, 배경색이 바뀌고 알림창이 뜨게하고싶은 경우!
// addEventListener (복수의 이벤트를 적용할 수 있습니다!)
// 세팅 > html 태그에 alert창 이벤트 설정하고 js에서는 백그라운드 컬러 변경 적용시켜보기 !

// const button = document.querySelector("button")
// const body = document.body

// function changeBack() {
//   document.body.style.backgroundColor = "green";
// }

// button.addEventListener("click", changeBack)



// 중요 ★★★★ addEventListener 활용해서 토글 이벤트 만들어보기!! ★★★★
// const button = document.querySelector("button")

// button.addEventListener("click", function() {
//   document.body.classList.toggle("convert")
// })


// ★★ 인풋 박스 안에 글자가 몇개 있는지 확인하는 이벤트
const button = document.querySelector("#btn");

button.addEventListener("click", function() {
  // 1. 인풋태그 안에 텍스를 알아야한다.
  // 2. 해당 텍스트의 개수를 알아야 한다.
  // 3. 해당 텍스트 개수의 숫자를 #result에 출력해야한다.

  const word = document.querySelector("#word");
  let count = word.value.length;
  const result = document.querySelector("#result")

  result.innerText = `${count}`
})

