// 이벤트 객체 : 이벤트가 발생하게 되었을 때, 어떤 요소에서 어떤 이벤트가 발생했는지에 대한 정보가 포함된 객체

// 객체 = 속성(*프로퍼티) / 기능(*메서드 = 함수)

// preventDefault : 대표적인 이벤트 객체 내 메서드 :
// 요소의 기본 속성값을 취소 및 무력화하는 메서드

// 이벤트 객체 > 프로퍼티
// pageX :현재 문서를 기준으로 이벤트가 발생하는 가로위치
// pageY :현재 문서를 기준으로 이벤트가 발생하는 세로위치

// target : 이벤트 요소, target : 이벤트가 발생한 대상을 반환
// > e.target


// 박스 pageX / pageY 이벤트 발생 알림창
// const box = document.querySelector("#box")

// box.addEventListener("click", function(e) {
//   alert(`이벤트 발생 위치 : ${e.pageX}, ${e.pageY}`)
// })



// ★★ 키보드 이벤트 
// e.code : 키보드로 입력한 키의 코드값
// e.key : 키보드로 입력한 키보드 값

// const body = document.body;
// const result = document.querySelector("#result");

// body.addEventListener("keydown", function(e) {
//   result.innerHTML = `
//   code : ${e.code},
//   key : ${e.key}
//   `
// })

// ★★★★★★ 슬라이더 만들어보기 ★★★★★★
// 1. 이미지를 출력할 공간에 대한 정의
// 2. 총 5장의 이미지 중 각각의 이미지를 선택했다고 할 수 있는 정의
// (* 이미지를 배열 객체로 만들기)
// 3. 버튼에 대한 기능 정의
// - 오른쪽 버튼 클릭, 이미지 한장씩 돌고
// - 왼쪽 버튼 클릭, 이미지가 반대로 한장씩 돌기
// 4. 만약 이미지가 처음 혹은 마지막에 도달했을 때, 원점으로 다시 돌아가게 하는 기능 정의

// window.addEventListener("contextmenu", function(e) {
//   e.preventDefault();
//   alert("오른쪽 버튼을 사용할 수 없습니다!")
// });

// const container = document.querySelector("#container")
// const pics = ["pic-1.jpg","pic-2.jpg","pic-3.jpg","pic-4.jpg","pic-5.jpg"];

// container.style.backgroundImage = `url(/img/${pics[0]})`

// const arrows = document.querySelectorAll(".arrow")
// let i = 0;

// arrows.forEach(function(e) {
//   e.addEventListener("click", function(e) {
//     if(e.target.id === "left") {
//       i--;
//       if(i < 0) {
//         i = pics.length -1;
//       }
//     } else if(e.target.id === "right") {
//       i++;
//       if( i >= pics.length) {
//         i = 0;
//       }
//     }
//     container.style.backgroundImage = `url(/img/${pics[i]})`
//   }) 
// });



// ★★ 마우스 오버 및 마우스아웃 이벤트 적용해보기

const imgBox = document.querySelector("#img")

imgBox.addEventListener("mouseover", function() {
  img.style.img= `/img/pic-6.jpg`
});

imgBox.addEventListener("mouseout", function() {
  img.style.img= `/img/pic-1.jpg`
});