const button = document.querySelector("button");
const log = document.querySelector(".log");

fetch("https://jsonplaceholder.typicode.com/comments")
.then((response) => response.json())
.then((data) => log.innerHTML = (data));


button.addEventListener("click", () => {

})