// 상세설명 보기 / 닫기 버튼을 클릭해서 내용 보여줄 수 있게하고 없어지게끔 하기 문제

// 내가 푼거 .. 
// const btn = document.querySelector("#view");
// const detail = document.querySelector("#detail")

// btn.onclick = () => {
//   detail.classList.toggle("click")
// }


// 선생님이 푼거 .. 
const viewBtn = document.querySelector("#view");
const detail = document.querySelector("#detail");

viewBtn.onclick = () => {
  detail.classList.toggle("hidden");
}