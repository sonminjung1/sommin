// ● 텍스트 input 태그 필드에 입력한 값 가져오기!!
// 선택요소.value

// 만약 id값과 class값이 없다면?
// > name을 활용해서 값을 가져 올 수 있다.



// 옵션 선택시 선택명 불러오기 !!!! ★★이거 꼭 공부해보기 !!!!
const selectMenu = document.querySelector("#option");

function displaySelect() {
  let selectedText = selectMenu.options[selectMenu.selectedIndex].innerText;
  alert(`[${selectedText}] 선택했습니다!`)
}

selectMenu.onchange = displaySelect
//온체인지는 ? 실제로 값이 변경되었을 때 실행되는 함수


