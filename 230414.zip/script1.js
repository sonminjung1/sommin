// ● DOM 개념 알기!!!!!!!!!! 왕중요

// * 자바스크립트를 왜 배울까? WHY??
// > 화면을 동적으로 움직이게 하기위해서!


// 문서객체모델 > 최상위클래스 : document 객체
// body 객체 = 요소
// h1 객체 = 요소
// p 객체 = 요소
// input 객체 = 요소


// 객체 : 속성 > *프로퍼티 / 기능 > *메서드

// html > 문서구조 > 태그 = 객체 > 요소
// : 요소에 접근한다 !

// > 요소에 접근 할 수 있는 함수 : 
// 1. querySelector()
// -> 무조건 낱개 요소(단일요소)에 접근
// -> 매개변수에 입력한 선택자 접근
// -> 해당 선택자가 document 안에 다수 존재하는 경우, 가장 첫번째로 선택된 요소에 접근! ex) p태그가 여러개인 경우 첫번째를 데리고 옴 !
// -> ★★★텍스트 노드 및 속성 노드까지 접근할 수 있다.


// 2. querySelectorAll(.user)
// -> 모든 요소에 접근! ex) p태그가 3개가 있다면, 3개를 다 데리고온다

// 3. getElementById () / getElementsByClassName ()
//  / getElementsByTagName ()
// -> ★★★ DOM 노드 중 요소 노드까지만 접근 할 수 있다.

// ● 요소 데이터 가져오는 방법 !!!!!

// 웹 요소 .innerText // ex)document.querySelector("#desc").innerText; > 웹브라우저에 있는 텍스트만 보여준다
// 웹 요소 .innerHTML > 웹브라우저에 있는 태그까지 모조리 다 불러온다
// 웹 요소 .textContent > 웹브라우저에 있는 태그를 빼곤 다 불러온다


// 웹 요소 .innerText = 바꾸고 싶은 내용
// 웹 요소 .innerHTML = 바꾸고 싶은 내용
// 웹 요소 .textContent = 바꾸고 싶은 내용

// 웹요소.src = 바꾸고 싶은 이미지 파일


// 클릭 시, 바뀌게 하는 것!
// const userName = document.querySelector("#desc p");
// const pfImg = document.querySelector("#profile img");

// userName.onclick = () => userName.innerHTML = `이름 : <b>아이돌</b>`
// pfImg.onclick = () => pfImg.src = "/img/iu2.jpg";



// ● CSS 속성에 접근하고 스타일 수정하는 방법 !!!!
//  > 수정하고싶은 요소.stlye.속성명 = 바꾸고싶은 스타일 값


// CSS 스타일 변경 예제!
// const title = document.querySelector("#title");

// title.onclick = () => {
//   title.style.backgroundColor = "black";
//   title.style.color = "white"
// }

// const name = document.querySelector("#name");

// name.onclick = () => {
//   name.style.backgroundColor = "blue"
//   name.style.color = "white"
// }

// ● classList 속성 (*프로퍼티) :
// > 해당 요소의 클래스 값을 배열객체 형태로 찾아준다!!
// > 선택한 선택요소.classList.add("클래스명") > 선택한 선택 요소에 클래스명을 추가 할 때 사용

// > 선택한 선택요소.classList.remove("클래스명") > 선택한 선택 요소에 클래스명을 삭제 할 때 사용

// > 선택한 선택요소.classList.contains("클래스명") > 선택한 선택 요소에 클래스명이 있는지 여부를 확인하는 함수

// > 선택한 선택요소.classList.toggle("클래스명") > 선택한 선택 요소에 클래스명이 있는지 여부를 확인하여 추가 및 삭제를 반복하는 함수





// ★ classList.add 예제문제 ★
// const title = document.querySelector("#title");

// title.onclick = () => {
//   title.classList.add("Clicked")
// }


// ★ classList.add 그리고 classList.remove 중복 사용하기 예제 ★
// const title = document.querySelector("#title");

// title.onclick = () => {
//   if(!title.classList.contains("Clicked")) {
//     title.classList.add("Clicked")
//   } else {
//     title.classList.remove("Clicked")
//   }
// }


// ★ classList.toggle 사용하기 예제 ★
// const title = document.querySelector("#title");

// title.onclick = () => {
//   title.classList.toggle("Clicked")
// }


// 데이 / 나이트 모드로 바꾸기
// const night = document.querySelector("#btn")
// const back = document.querySelector("body")

// night.onclick = () => {
//   back.classList.toggle("click")
// }



