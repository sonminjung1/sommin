const btn = document.querySelector("#btn");
const detail = document.querySelector("#detail");

btn .onclick = () => {
  detail.classList.toggle("click")
}