const finish = document.querySelector("#finish");
const randomNumberBtn = document.querySelector("#randomNumberBtn");
const finishBtn = document.querySelector("#finishBtn");
const join = document.querySelector("#join")
const randomNumber = document.querySelector("#randomNumber");

let timer = document.querySelector("#timer");


// 폰번호 자동으로 넘어가게 만들기
let check1 = () => {
  let num1 = document.querySelector("#num1").value;
  if (num1.length === 3) {
    document.querySelector("#num2").focus()
  }
}

let check2 = () => {
  let num1 = document.querySelector("#num2").value;
  if (num1.length === 4) {
    document.querySelector("#num3").focus()
  }
}
const check3 = function() {
  let num1 = document.querySelector("#num1").value;
  let num2 = document.querySelector("#num2").value;
  let num3 = document.querySelector("#num3").value;

  if (num3.length === 4) {
    document.querySelector("#randomNumberBtn").focus()
  }
}

  if( num1 !== "" && num2 !== "" && num3 !== "" ) {
    randomNumberBtn.disabled = false;
  } else {
    randomNumberBtn.disabled = true;
  }


randomNumberBtn.addEventListener("click", function(e) {
  e.preventDefault()

  document.querySelector("#finishBtn").disabled = false
  let random = String(Math.floor(Math.random() * 1000000)).padStart(6, "0");
  randomNumber.innerHTML = random

  let time = 180;

  setInterval(() => {
    if (time >= 0) {
      let min = String(Math.floor(time / 60)).padStart(2, "0") // 소수점 버리기
      let sec = String(time % 60).padStart(2, "0");

      timer.innerHTML = `${min} : ${sec}`
  
      time = time - 1
    } else {
      isStarted = false;
    }
  }, 1000)
});