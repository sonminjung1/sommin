// 1. 로컬스토리지 저장
// 2. 삭제하기 버튼 > 리셋
// 3. 전체삭제 버튼 > 전체삭제

const section = document.querySelector('.localStorage');
const btnSave = document.querySelector('.btnSave');
const btnRemove = document.querySelector('.btnRemove');
const btnClear = document.querySelector('.btnClear');
const input = document.querySelector('input');

btnSave.addEventListener('click', () => {
  const data = input.value;
  
  localStorage.setItem('key', data);
});

btnRemove.addEventListener('click', () => {
  const data = localStorage.removeItem('key');
  

});

btnClear.addEventListener('click', () => {
  const data = localStorage.clear('key');
  

})