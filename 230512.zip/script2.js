// 3초 뒤에 오케이 출력 > 딜레이
// setTimeout(function() {
//   console.log("OK")
// }, 3000);

// 1초마다 반복적으로 오케이 출력하기 > 반복
// setInterval(function() {
//   console.log("OK")
// }, 1000);

// 10부터 0까지 카운트하기!
// let time = 10;

// setInterval(function() {
//   if (time >= 0) {
//     console.log(time)
//     time = time - 1;
//   }  
// }, 1000);

// setInterval 함수를 사용해서 3분부터 0초까지 출력이 되게끔
// 코드를 작성해보세요
