// 인풋 태그에 다 입력했을 때 회원가입 버튼이 활성화되게 만들기

// const check = function() {
//   let email = document.querySelector("#email").value;
//   let pw1 = document.querySelector("#password1").value;
//   let pw2 = document.querySelector("#password2").value;

//   if(email && pw1 && pw2 ) {
//     document.querySelector("#submit").disabled = false;
//   } else {
//     document.querySelector("#submit").disabled = true;
//   }
// }