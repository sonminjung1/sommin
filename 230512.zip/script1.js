// let name = prompt("당신의 이름은?");

// ★ 기본함수
// function hello(name) {
//   alert(name + "님 안녕하세요");  
// }
// hello(name);

// ★ 익명함수
// const hello = function(name) {
//   alert(name + "님 안녕하세요");  
// }
// hello(name);

// ★ 화살표 함수
// const hello = (name) => {
//   alert(name + "님 안녕하세요");  
// }
// hello(name);

// ★ return문
// const num1 = 1;
// const num2 = 2;

// function add(a, b) {
//   return a + b
// }
// document.write(add(num1, num2))

// ★ 리턴문 화살표 함수
// const num1 = 1;
// const num2 = 2;

// let add =  (a, b) => {
//   return a + b
// }
// document.write(add(num1, num2))

//====================== ★ 문제 1 ★ ============================

// 사용자로부터 이메일과 비밀번호를 받고,
// 해당 이메일과 비밀번호 정보가 일치한지 검증하는
// 함수를 만들어주세요


// const email = "email@naver.com";
// const password = 1234;

// const userEmail = prompt("당신의 이메일은?");
// const userPassword = prompt("당신의 비밀번호는?");

// function solution(email, password) {
//   if (email !== userEmail) {
//     alert("이메일이 틀렸습니다.")
//   } else if (password !== userPassword) {
//     alert("비밀번호가 틀렸습니다.")
//   } else if (password !== userPassword) {
//     alert ("비밀번호가 틀렸습니다.")
//   }
// }
// document.write(solution(email, password))

//==================================================

// 이건 검색해서 나온 것.
// function checkCredentials(email, password) {
//   const validEmail = "email@naver.com";
//   const validPassword = 1234;

//   if (email === validEmail && password === validPassword) {
//     return true; // 이메일과 비밀번호가 일치하는 경우
//   } else {
//     return false; // 이메일과 비밀번호가 일치하지 않는 경우
//   }
// }

// // 예시 사용법
// const email = "email@naver.com";
// const password = 1234;

// const result = checkCredentials(email, password);
// console.log(result); // true (일치하는 경우)


//====================== ★ 문제 2 ★ ============================

// 버튼 인증번호 전송 누르면 6자리 랜덤값 나오게하기
// ★ 내가 푼 것

// const number = document.querySelector(".number");
// const btn = document.querySelector("button");


// btn.addEventListener("click", (e) => {
//   e.preventDefault();

//   let random = String(Math.floor(Math.random() * 1000000)).padStart(6, "0");

//   number.innerText = random;
//   number.style.color = `#${random}`
  
// })

// 버튼 인증번호 전송 누르면 6자리 랜덤값 나오게하기
// ★ 선생님이 푼 것
// 이벤트핸들러 사용해서 만들어보기

// function random() {
//   let token = String(Math.floor(Math.random() * 1000000)).padStart(6, "0");
//   document.querySelector("#target").innerHTML = token
// }


// =============== 예제 종합문제  =========================

const number = document.querySelector(".number");
const btn = document.querySelector("button");
let timer = document.querySelector("#timer")
let time = 180;



btn.addEventListener("click", (e) => {
  e.preventDefault();

  let random = String(Math.floor(Math.random() * 1000000)).padStart(6, "0");

  number.innerText = random;
  number.style.color = `#${random}`

  setInterval(() => {
    if (time >= 0) {
      let min = String(Math.floor(time / 60)).padStart(2, "0") // 소수점 버리기
      let sec = String(time % 60).padStart(2, "0");

      timer.innerHTML = `${min} : ${sec}`
  
      time = time - 1
    } else {
      document.querySelector("#completed").disabled = true
    }
  }, 1000)
})


