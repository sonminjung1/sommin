// =============== 예제 종합문제  =========================
// 카운터 활성화 여부

let isStarted = false;
const number = document.querySelector("#number");
const btn = document.querySelector(".send-btn");
let timer = document.querySelector("#timer")

// const check = function() {
//   let num1 = document.querySelector("#num1").value;
//   let num2 = document.querySelector("#num2").value;
//   let num3 = document.querySelector("#num3").value;

//   if(num1 && num2 && num3 ) {
//     btn.disabled = false;
//   } else {
//     btn.disabled = true;
//   }
// }

let check1 = () => {
  let num1 = document.querySelector("#num1").value;
  if (num1.length === 3) {
    document.querySelector("#num2").focus()
  }
}

let check2 = () => {
  let num1 = document.querySelector("#num2").value;
  if (num1.length === 4) {
    document.querySelector("#num3").focus()
  }
}

const check3 = function() {
  let num1 = document.querySelector("#num1").value;
  let num2 = document.querySelector("#num2").value;
  let num3 = document.querySelector("#num3").value;

  if(num1 && num2 && num3 ) {
    btn.disabled = false;
  } else {
    btn.disabled = true;
  }
}



btn.addEventListener("click", (e) => {
  e.preventDefault();

  if(isStarted === false) {
    //카운터가 작동중이지 않을 때
    isStarted = true;
    let random = String(Math.floor(Math.random() * 1000000)).padStart(6, "0");

    number.innerText = random;
    number.style.color = `#${random}`

    let time = 180;

  
    setInterval(() => {
      if (time >= 0) {
        let min = String(Math.floor(time / 60)).padStart(2, "0") // 소수점 버리기
        let sec = String(time % 60).padStart(2, "0");
  
        timer.innerHTML = `${min} : ${sec}`
    
        time = time - 1
      } else {
        document.querySelector("#completed").disabled = true
        isStarted = false;
      }
    }, 1000)
  } else {
    //카운터가 작동중일 때???
  }
})
