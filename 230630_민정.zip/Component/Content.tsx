import React from 'react'

const Content = ({ text, onClick, onChange}) => {
  return (

    <div className='join-box'>
    <div className='header'>
      <h1>회원가입을 위해
        <br />
        정보를 입력해주세요
      </h1>
    </div>
    <div className='Content'>
      <div className='text'>
        <label>* 이메일</label>
        <input onChange={onChange} type="text" />
      </div>
      <div className='text'>
        <label>* 이름</label>
        <input value={text} onChange={onChange} type="text" />
      </div>
      <div className='text'>
        <label>* 비밀번호</label>
        <input value={text}  onChange={onChange} type="password" />
      </div>
      <div className='text'>
        <label>* 비밀번호 확인</label>
        <input value={text} onChange={onChange} type="password" />
      </div>
      <div className="gender">
        <input name='gender' type="radio" /> 여성
        <input name='gender' type="radio" /> 남성
      </div>
      <div className='degree'>
        <input type="checkbox" /> 이용약관 개인정보 수집 및 이용, 마케팅 활용 모두 동의합니다.
      </div>
      <hr />
    </div>
    <div>
      <button onClick={onClick} className='button'>가입하기</button>
    </div>
    </div>
  )
}

export default Content
