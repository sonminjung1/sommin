import React from 'react';
import logo from './logo.svg';
import './App.css';
import Content from './Component/Content';
import { useState } from 'react';
function App() {

  const [text, setText] = useState("")
  const onChange = (e) => {
    setText(e.target.value)
  }
  const onClick = () => {
    if(text) {
      alert("값을 입력 해 주세요")
    } else {
      alert("축하해요!")
    }
  }
  return (
    <div className="join">
      <Content text="text" onClick={onClick} onChange={onChange}></Content>
    </div>
  );
}

export default App;
