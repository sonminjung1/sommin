// async / await 예제문제~

async function init() {
  const response = await fetch("https://jsonplaceholder.typicode.com/users"); //JSON 파일 주소 복사해서 가져오기
  const users =  await response.json();
  display(users) // 함수호출
}

function display(users) {
  const result = document.querySelector("#result");
  let string = "";
  // forEach 각각의 데이터를 넣기위해!
  users.forEach((user) => {
    string += `
    <table>
    <tr><th>이름</th><td>${user.name}</td></tr>
    <tr><th>아이디</th><td>${user.username}</td></tr>
    <tr><th>이메일</th><td>${user.email}</td></tr>
    </table>
    `;
  });
  result.innerHTML = string;
}
init()  // 함수호출