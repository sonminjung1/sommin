// const canvas = document.querySelector("canvas");
// const ctx = canvas.getContext("2d");

// ctx.fillStyle = "rgb(200, 0, 0)";
// 실제로 들어가는 색상 지정
// ctx.fillRect(10, 10, 50, 100);
// 캔버스 위치 설정하긔 ..


// canvas.width = window.innerWidth;
// canvas.height= window.innerHeight;

// 캔버스 사이즈 전체로 하기

// 90도 = Math.PI * 0.5
// 180도 = Math.PI
// 270도 = Math.PI * 1.5
// 360도 = 0도 = Math.PI * 2

// 만약 역시계방향으로 -90도로 가고싶을 땐?

// * 사각형을 그리는 메서드 .........
// 1. fillRect(x, y, width, height) : 색상을 채우는 사각형을 만들 때
// 2. strokRect(x, y, width, height) : 테두리만 있는 사각형을 만들 때
// 3. clearRect(x, y, width, height) : 특정 위치 및 사이즈의 사각영역을 지울 때

// ==================== 사각형 ====================
// const canvas = document.querySelector("canvas") // 기본세팅
// const ctx = canvas.getContext("2d") // 필수사항!


// ctx.fillStyle = "rgb(200, 0, 0)";
// ctx.fillRect(10, 10, 200, 100);
// ctx.strokeStyle = "blue"
// ctx.strokeRect(10, 10, 200, 100);

// ctx.fillStyle = "rgba(0, 0, 200, 0.5)"; // 반투명!
// ctx.fillRect(50, 50, 120, 100);

// ctx.clearRect(70, 80, 80, 45); // 삭제하긔


// ==================== 삼각형1 ====================

// * 삼각형을 그리는 메서드 .........
// 1. beginPath() : 사각형을 제외한 나머지 도형을 그리기위한 첫번째 시그널
// 2. closePath() : 나머지 도형을 다 그렸다는 마지막 시그널
// 3. lineTo(x, y) : 시작점에서부터 (x, y)좌표값까지 직선 경로를 만들겠다고 선언하는 메서드
// 4. moveTo(x, y) : 도형을 그릴 때, 시작점을 정의하는 메서드
// 5. stroke() : 선에 대한 경로 설정 후 해당 메서드를 반드시 입력해야만 화면에 출력됩니다.
// 6. fill() : 배경설정 후 해당 메서드를 반드시 입력해야만 화면에 배경이 채워집니다.

// const canvas = document.querySelector("canvas") // 기본세팅
// const ctx = canvas.getContext("2d") // 필수사항!

// ctx.beginPath();
// ctx.moveTo(50, 50);
// ctx.lineTo(200, 200);
// ctx.stroke();
// ctx.closePath();

// ctx.beginPath();
// ctx.moveTo(350, 50);
// ctx.lineTo(200, 200);
// ctx.stroke();
// ctx.closePath();

// ==================== 삼각형2 ====================
// const canvas = document.querySelector("canvas") // 기본세팅
// const ctx = canvas.getContext("2d") // 필수사항!




// ==================== 삼각형3 ====================
// const canvas = document.querySelector("canvas") // 기본세팅
// const ctx = canvas.getContext("2d") // 필수사항!

// // 첫번째
// ctx.beginPath();
// ctx.moveTo(50, 50);
// ctx.lineTo(150, 100);
// ctx.lineTo(50, 150);
// ctx.closePath();
// ctx.stroke();

// // 두번째
// ctx.beginPath();
// ctx.moveTo(150, 100);
// ctx.lineTo(250, 50)
// ctx.lineTo(250, 150);
// ctx.closePath();
// ctx.fillStyle = "rgba(0, 200 ,0)" // 색상값주기!
// ctx.fill();

// ==================== 원 ====================

// * 원을 그리는 메서드 .........
// 1. arc(x, y, r, startAngle, endAngle, counterClockwise)
// x, y = 원의 중심점 > 스타트 시작점인데 중심을 기준으로 움직인다는 것!
// r = 원의 반지름
// startAngle = 시작이 될 radian값
// endAngle = 끝점이 될 radian값
// counterClockwise = 반시계 반향으로 도는 것을 기본값으로 인식한다
// 그러므로 만약에 true가 나오면? 반시계 반향 / false가 나오면? 시계 반향
// counterClockwise는 원일 때 안써도 됌, 반원일땐 써야함

// const canvas = document.querySelector("canvas") // 기본세팅
// const ctx = canvas.getContext("2d") // 필수사항!

// ctx.strokeStyle = "red"; // 이걸 맨 처음에 줘야한다,,,,
// ctx.fillStyle = "yellow";

// ctx.beginPath();
// ctx.arc(200, 150, 100, 0, Math.PI*2)
// ctx.stroke();
// ctx.closePath();


// ==================== 반원1 ====================

// const canvas = document.querySelector("canvas") // 기본세팅
// const ctx = canvas.getContext("2d") // 필수사항!

// ctx.fillStyle = "red"

// ctx.beginPath();
// ctx.arc(120, 100, 50, 0, Math.PI, true)
// ctx.fill();
// ctx.closePath();

// ctx.beginPath();
// ctx.arc(280, 100, 50, 0, Math.PI, false)
// ctx.fill();
// ctx.closePath();

// 중복되는건 지워도 된다 더 간략하게 쓰자

// ctx.fillStyle = "red"

// ctx.beginPath();
// ctx.arc(120, 100, 50, 0, Math.PI, true)
// ctx.arc(280, 100, 50, 0, Math.PI, false)
// ctx.fill();
// ctx.closePath();

// ==================== 반원2 ====================

// const canvas = document.querySelector("canvas") // 기본세팅
// const ctx = canvas.getContext("2d") // 필수사항!

// // 반원 검정색 2개
// ctx.beginPath();
// ctx.arc(120, 100, 50, 0, Math.PI, true)
// ctx.arc(280, 100, 50, 0, Math.PI, false)
// ctx.fill();
// ctx.closePath();

// // 반원 스트로크 
// ctx.beginPath();
// ctx.arc(120, 200, 50, (Math.PI/180)*90, (Math.PI/180)*270, false);
// ctx.closePath();
// ctx.stroke();

// // 호 만들어보기

// ctx.strokeStyle = "blue"
// ctx.beginPath();
// ctx.arc(200, 200, 50, 0, (Math.PI / 180) * 60, false);
// ctx.stroke();

// ==================== 타원 ====================
// * 타원을 그리는 메서드 .........
// ellipse(x, y, radiusX,radiusY,rotation, startAngle, endAngle, counterClockwise)

// x, y = 타원의 중심
// radiusX, radiusY =타원의 가로 및 세로 반지름
// rotation = 타원의 회전 각도
// startAngle = 시작이 될 radian값
// endAngle = 끝점이 될 radian값
// counterClockwise = 반시계 반향으로 도는 것을 기본값으로 인식한다
// 그러므로 만약에 true가 나오면? 반시계 반향 / false가 나오면? 시계 반향
// counterClockwise는 원일 때 안써도 됌, 반원일땐 써야함

// 타원 1 그려보자!
// const canvas = document.querySelector("canvas") // 기본세팅
// const ctx = canvas.getContext("2d") // 필수사항!

// ctx.strokeStyle = "red"

// ctx.beginPath();
// ctx.ellipse(200, 70, 80, 50, 0, 0, Math.PI * 2);
// ctx.closePath();
// ctx.stroke();

// // 타원 2 그려보자!
// ctx.strokeStyle = "blue"
// ctx.beginPath();
// ctx.ellipse(150, 200, 80, 50, (Math.PI / 180) * -30, 0, Math.PI * 2);
// ctx.closePath();
// ctx.stroke();

// ==================== 타원2 ====================
// 타원을 그리는 두번째 방법

// 기본적인 정원의 사이즈 변경을 통해서 가능
// scale(x, y);

// const canvas = document.querySelector("canvas") // 기본세팅
// const ctx = canvas.getContext("2d") // 필수사항!

// ctx.strokeStyle = "blue";
// ctx.scale(1, 0.8) // 스케일을 사용한게 인싸이트!
// ctx.beginPath();
// ctx.arc(200, 150, 80, 0, Math.PI * 2);
// ctx.closePath();
// ctx.stroke();

// // 스케일이 상속을 받음,,
// // 스케일을 어디 위치에 놓느냐가 중요하다!!!!!
// // 스케일을 안쪽에 있는 원만 변경하고싶다면,
// // 작은 원의 beginPath() 위에 적자 ^^
// ctx.beginPath();
// ctx.arc(200, 150, 30, 0, Math.PI * 2)
// ctx.closePath();
// ctx.stroke();

// ==================== 곡선 ====================
// * 곡선을 그리는 메서드 .........
// : 베지에 Bezier
// 포토샵에서 펜툴 생각하기!! 펜툴 쓸 때 시작점 말고 다른곳 클릭시 2번째 클릭하는 것 부터가 조절점이라고 생각하면 된다.

// - 2차 베지에 곡선 (*조절점이 1개)
//  quadraticCurveTo > [ cpx, cpy, x, y ]

//  cpx, cpy : 조절점 좌표
//  x, y : 곡선이 끝나는 좌표 

//--------------2차 베지에 ---------------
// const canvas = document.querySelector("canvas") // 기본세팅
// const ctx = canvas.getContext("2d") // 필수사항!

// ctx.beginPath();
// ctx.moveTo(50, 200); // 첫 스따뜨 > x에서 50, y에서 200 (점시작,,)
// ctx.quadraticCurveTo(100, 50, 350, 200);
// ctx.stroke();

// - 3차 베지에 곡선 (* 조절점이 2개)
//  bezierCurveTo > [ cpx1, cpy1, cpy2, cpy2, x, y ]

//--------------3차 베지에 ---------------
// const canvas = document.querySelector("canvas") // 기본세팅
// const ctx = canvas.getContext("2d") // 필수사항!

// ctx.beginPath();
// ctx.moveTo(50, 100);
// ctx.bezierCurveTo(100, 50, 150, 100);
// ctx.stroke();

// const canvas = document.querySelector("canvas") // 기본세팅
// const ctx = canvas.getContext("2d") // 필수사항!


// ctx.beginPath();
// ctx.moveTo(50, 100);
// ctx.quadraticCurveTo(100, 50, 150, 100);
// ctx.quadraticCurveTo(200, 150, 250, 100);
// ctx.quadraticCurveTo(300, 50, 350, 100);
// ctx.stroke();

//--------------3차 베지에 ---------------
// const canvas = document.querySelector("canvas") // 기본세팅
// const ctx = canvas.getContext("2d") // 필수사항!

// ctx.strokeStyle = "green"
// ctx.beginPath();
// ctx.moveTo(50, 100);
// ctx.bezierCurveTo(90, 250, 310, 10, 350, 100);
// ctx.stroke();

//--------------★ 삼각형 내장객체 만들어보기 ★---------------
const canvas = document.querySelector("canvas") // 기본세팅
const ctx = canvas.getContext("2d") // 필수사항!

// let triangle = new Path2D()
// triangle.moveTo(100, 100);
// triangle.lineTo(300, 100);
// triangle.lineTo(200, 260);
// triangle.closePath();

// let circle = new Path2D()
// circle.arc(200, 150, 50, 0, Math.PI * 2);

// ctx.stroke(triangle);
// ctx.fillStyle = "green"
// ctx.fill(circle)

//--------------★ 개구리 만들어보기 ★---------------
// face
// ctx.scale(1, 0.8)
// ctx.fillStyle = "green"
// ctx.strokeStyle = "black"
// ctx.beginPath();
// ctx.arc(150, 150, 80, 0, Math.PI * 2);
// ctx.fill();
// ctx.stroke();

// // eye
// ctx.fillStyle = "white"
// ctx.strokeStyle = "green"
// ctx.beginPath();
// ctx.arc(120, 80, 20, 0, Math.PI * 2);
// ctx.moveTo(200, 80);
// ctx.arc(180, 80, 20, 0, Math.PI * 2);
// ctx.fill();
// ctx.stroke();

// ctx.fillStyle = "black"
// ctx.beginPath();
// ctx.arc(120, 90, 7, 0, Math.PI* 2);
// ctx.moveTo(200, 80);
// ctx.arc(180, 90, 7, 0, Math.PI * 2);
// ctx.fill();

// // mouse
// ctx.beginPath();
// ctx.arc(150, 150, 50, 0, Math.PI);
// ctx.fillStyle = "red"
// ctx.lineWidth = 3
// ctx.fill();
// ctx.stroke()

//--------------★ 텍스트를 그려보자.. ★---------------

// - fillText (text, x, y)
// - strokeText (text, x, y)
// >> text : 캔버스에 그릴 텍스트를 의미
// >> x, y : 텍스트를 표기할 좌표값

// 폰트사이즈를 반드시 지정해줘야한다!!!
// ctx.strokeStyle = "green"
// ctx.fillStyle = "pink"
// ctx.font = "italic 60px serif"
// ctx.fillText("HELLO", 50, 70);

// ctx.font = "bold 60px sans-serif"
// ctx.strokeText("GOOD BYE", 50, 150)



//--------------★ 캔버스에 이미지 표시하기★---------------
// - drawImage (image, dx, dy)
// - drawImage (image, sx, sy, sw, sh, dx, dy, dw, dh)
// : image = 캔버스에 띄울 이미지 객체 타입
// : dx / dy = 캔버스 좌측 상단으로부터 얼마나 떨어진 지점에 위치를 둘것이냐,,, 
// => 내장객체를 사용,,

// let image = new Image()
// // 이벤트 핸들러 사용하긔 꼭 기억해~
// image.onload = function() {
//   // ctx.drawImage(image, 0, 0, canvas.width, canvas.height);
//   ctx.drawImage(image, 100, 50, 280, 350, 160, 100, 140, 175);
// }
// image.src = "/img/cat.jpg";

//-------------- 이미지 클리핑하기 !!!!---------------
// - clip()
// let img = new Image()
// img.onload = function() {
//   ctx.drawImage(img, 0, 0, canvas.width, canvas.height);
// }
// img.src = "/img/bird.jpg";
// ctx.beginPath();
// ctx.arc(250, 120 , 100, 0, Math.PI * 2);
// ctx.clip();

//-------------- ★...별 그리기...★ ---------------

// ctx.fillStyle = "yellow"
// ctx.beginPath();
// ctx.moveTo(80, 100); // x값 / y값
// ctx.lineTo(310, 100);
// ctx.lineTo(120, 250);
// ctx.lineTo(190, 30);
// ctx.lineTo(280, 250);
// ctx.lineTo(80, 100);
// ctx.closePath();

// ctx.fill()
// ctx.stroke();

//-------------- ★...냐옹이 클리핑 마스크...★ ---------------
let cat = new Image()
cat.onload = function() {
  ctx.drawImage(cat, 0, 0, canvas.width, canvas.height);
}
cat.src = "img/cat.jpg"
ctx.beginPath();
ctx.ellipse(180, 150, 100, 140, 0, 0, Math.PI * 2);
ctx.clip();