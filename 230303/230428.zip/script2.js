const quoteURL = "http://dummyjson.com/quotes";
fetch(quoteURL)
.then(response => response.json()) // 이거 쫌 이해 안감..
// .then(data => {console.log(data)}) //콘솔창으로 확인해보기!

.then(data => {
  const result = document.querySelector("#result");
  const random = Math.floor(Math.random() * 30);
  result.querySelector(".quote").innerHTML = data.quotes[random].quote;
  result.querySelector(".author").innerHTML = `- ${data.quotes[random].author}`;
})