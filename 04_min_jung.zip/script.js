import log from "./MyClass1"

// const log = document.querySelector("div");
log.innerHTML = "<p>오늘은 기분 좋은 날이에요!</p>"