// 문제 1
// 사용자로부터 대소문자가 섞인 영단어를 받아서
// 대문자는 소문자로, 소문자는 대문자로 콘솔창에 출력하기

// let str = String(prompt("대소문자 입력"))

// function solution(e) {
//   let answer = "";
//   for (let el of e) {
//     if (el === el.toUpperCase()) {
//       answer += el.toLowerCase();
//     } else {
//       answer += el.toUpperCase();
//     }
//   }

//   return answer
// }
// console.log(solution(str));

// 문제 2
// 소문자를 모두 대문자로 바꾸시오 
// let str = String(prompt("대소문자 입력"));

// function solution(e) {
//   let answer = "";

//   for (let el of e) {
//     if (el === el.toLowerCase()) {
//       answer += el.toUpperCase();
//     } else {
//       answer += el
//     }
//   }

//   return answer
// }
// console.log (solution(str))


// 문제 3
// 1 사용자로부터 대소문자 섞인 영단어 받기
// 2. 해당 단어중에서 대문자가 총 몇개인지 확인 후 콘솔창에 **단어에서 대문자는 총 **개입니다. 출력하기

// let str = prompt("대소문자를 입력해주세요");

// function solution(e) {
  
//   let answer = 0;
//   // 개수를 구해야하기때문에 "" 이게 아니라 0으로 설정해야함!

//   for(let el of e) {
//     if (el === el.toUpperCase()) {
//       answer++;
//     }
//   }

//   let take = `${str}에서 대문자는 총 ${answer}입니다.`
//   return take;
// }
// console.log(solution(str))

// 문제 4
// 사용자로부터 대소문자 영단어를 받고
// 사용자로부터 찾고싶은 단어가 무엇인지 받으세요

// 콘솔창에 찾고싶은 단어, **은 **개 있습니다.

// let str = prompt("대소문자 영단어를 입력해주세요");
// let world = prompt("찾고싶은 단어는?")

// function solution(a, b) {
//   let answer = 0;
//   for (let el of a) {
//     if(el === b) {
//       answer++;
//     }
//   }
//   let take = `${world}스펠링은 총 ${answer}입니다`
//   return take;
// }
// console.log(solution(str, world));

// 문제 5
// 사용자로부터 대문자 A를 받았을 때 콘솔창에 #으로 출력되게 해주세여
// 단 소문자a 를 받았을때도 마찬가지로 #으로 출력
let str = prompt("영문을 입력해보세요");

function solution(e) {
  let answer = e;
  answer = answer.replace("A", "#");
  answer = answer.replace("a", "#");
  
  return answer
}
console.log(solution(str));