// ==============코딩 테스트 문제 1 최소값 구하기 =============

// let num1 = parseInt(prompt("첫번째 숫자를 입력해 주세요"));
// let num2 = parseInt(prompt("두번째 숫자를 입력해 주세요"));
// let num3 = parseInt(prompt("세번째 숫자를 입력해 주세요"));

// function solution(a, b, c) {
//   if (a < b) {
//     answer = a;
//   } else {
//     answer = b;
//   }

//   if (c < answer) {
//     answer = c;
//   }
//   return answer;
// }
// console.log(solution(num1, num2, num3))

// 사용자로부터 숫자를 받고 최대값 구하긔.. 코딩테스트 1-1
// let num1 = parseInt(prompt("첫번째 숫자를 입력해 주세요"));
// let num2 = parseInt(prompt("두번째 숫자를 입력해 주세요"));
// let num3 = parseInt(prompt("세번째 숫자를 입력해 주세요"));

// function solution(a, b, c) {
//   if (a > b) {
//     answer = a;
//   } else {
//     answer = b;
//   }

//   if (c > answer) {
//     answer = c;
//   }
//   return answer;
// }
// console.log(solution(num1, num2, num3))

/// 사용자로부터 삼각형 변 값을 받고 해당값을 통해서
// 삼각형을 만들 수 있다면 콘솔창에 Yes 출력,
// 만약 삼각형을 만들 수 없다면 No 출력.. 코딩테스트 2



// let num1 = parseInt(prompt("첫번째 숫자를 입력해 주세요"));
// let num2 = parseInt(prompt("두번째 숫자를 입력해 주세요"));
// let num3 = parseInt(prompt("세번째 숫자를 입력해 주세요"));


// 내가 푼 것!
// function result(a, b, c) {
//   if (a > b) {
//     answer = a;
//   } else {
//     answer = b;
//   }
//   if (c > answer) {
//     answer = c;
//   }
//   if (answer > a) {
//     console.log("No")
//   } else if (answer > b) {
//     console.log("No")
//   } else if (answer > c) {
//     console.log("No")
//   }
// }

// console.log(result(num1, num2, num3))

// 선생님이 푼 것!

// function result(a, b, c) {
//   let answer = "Yes";
//   let max = "";
//   let total = a + b + c;

//   if (a > b) {
//     max = a;
//   } else {
//     max = b;
//   }
//   if (c > max) {
//     max = c;
//   }

//   if (total - max <= max) {
//     answer = "No"
//   }
//   return answer;
// }
// console.log(result(num1, num2, num3))

// ==============코딩 테스트 문제 3 =============

// 설명 : 사용자에게 빵 몇개 줄수 있는지 물어보고
// 우리 16명이 전달 받은 빵을 각각 몇개씩 나눠먹을 수 있는지
// 콘솔창에 출력

// 내가 푼 것!
// let eat = parseInt(prompt("빵을 몇개 줄 수 있니?"));
// let result = eat / 16;
// let solution = Math.floor(result);
// // function divide() {
// //   let result = eat / 16
// // }
// console.log(solution);

// 선생님이 푼 것
// let eat = parseInt(prompt("빵을 몇개 줄 수 있니?"));
// function solution(e) {
//   if( e < 16) {
//     console.log("장난하냐")
//   } else {
//     let answer = Math.floor(e/16);
//     return answer
//   }
// }
// console.log(solution(eat));

// ==============코딩 테스트 문제 4 =============

// 내가 푼 것
// let num = parseInt(prompt("1부터 더할 숫자를 입력하세요"));

// function solution(n) {
//   let sum = 0;
//   for (let i = 1; i < n; i++) {
//     sum += i;
//   }

//   return sum
// }
// console.log(solution(num))

// 선생님이 푼 것
// let num = parseInt(prompt("1부터 더할 숫자를 입력하세요"));

// function solution(e) {
//   let answer = 0;
//   for (let i = 0; i <= e; i++) {
//     answer += i;
//   }
//   return answer;
// }
// console.log(solution(num))

// ==============코딩 테스트 문제 5 =============
// 해당 배열에서 최소값을 찾아 콘솔창에 출력해주세요!

// let arr = [5, 7, 1, 3, 2, 9, 11];

// function solution(e) {
//   let answer = Number.MAX_SAFE_INTEGER;
//   let max = 12;
//   for (let i = 0; i < arr.length; i++) {
//     if (arr[i] < max) {
//       max = arr[i];
//     }

//     answer = max;
//   }
//   return answer;
// }
// console.log(solution(arr));

// 만약 max값이 정해져있지 않다면 ? Number.MAX_SAFE_INTEGER 이걸 써주라
// Number.MAX_SAFE_INTEGER;
// 9007199254740991

// ==============코딩 테스트 문제 6 =============
// 배열객체에서 홀수값만 더하기 하고, 더하기한 결과값과 이중 가장 작은 수만 콘솔창에 출력

let arr = [12, 77, 38, 41, 53, 92, 85]

function solution(e) {
  let answer = [];
  let sum = 0;
  let min = Number.MAX_SAFE_INTEGER

  for(let el of e) {
    if(el % 2 === 1) {
      sum += el;
      if(el < min) {
        min = el; //대입해주기
      }
    } 
  }
  answer.push(sum);
  answer.push(min);
  return answer
}

console.log(solution(arr))